CREATE TRIGGER testHistory_AFTER_INSERT
AFTER INSERT ON testHistory
FOR EACH ROW
  BEGIN
UPDATE testHistory
       set response_status = 
		CASE
	        WHEN TIMESTAMPDIFF(SECOND, question_start_time, question_end_time) < 5 then 'pass'
            WHEN TIMESTAMPDIFF(SECOND, question_start_time, question_end_time) >= 5 then 'fail'
		end ;
END;
